<?php

//Database connections
function acmeConnection() {
    $server = "localhost";
    $database = "acm";
    $user = "iClient";
    $password = "k1CjDdGOpu9aJdlw";
    $dsn = "mysql:host=$server;dbname=$database";
    $options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);

    try {
        $acmeLink = new PDO($dsn, $user, $password, $options);        
        return $acmeLink;
    } catch (PDOException $ex) {
        header('location: ../errordocs/500.php');
    }
}

acmeConnection();