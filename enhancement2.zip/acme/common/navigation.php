<div class="nav">
        <ul>
         <li><a href="/home.php">Home</a><li>
         <li><a href="/anvils">Anvils</a><li>
         <li><a href="/cannons">Cannons</a><li>
         <li><a href="/protection">Protection</a><li> 
         <li><a href="/rockets">Rockets</a><li>
         <li><a href="/traps">Traps</a><li>
        </ul>
</div>