
    <img src="/acme/images/site/logo.gif" alt="logo for my site">

    <div id="tools">
      
        <a href="x" title="Login or Register">My Account</a>
    </div>


