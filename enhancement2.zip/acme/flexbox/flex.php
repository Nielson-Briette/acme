<!DOCTYPE html>
<<html>
    <head>
        <title>Flexbox</title>
        <link href="flex.css" type="text/css" rel="stylesheet" media="screen">
    </head>
    <body>
        <header>Header</header>
            <div>
                <nav>Navigation</nav>
                <main>Main Content</main>
                <aside>Aside</aside>
            </div>
        <footer>Footer</footer>
    </body>
</html>
